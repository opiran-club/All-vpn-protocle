#!/bin/bash
echo  installing DOCKER
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

