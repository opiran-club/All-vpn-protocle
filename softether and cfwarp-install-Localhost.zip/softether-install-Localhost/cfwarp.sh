#!/bin/bash
#warp
figlet CFwarp
# Download and run CFwarp.sh script
wget -N https://gitlab.com/rwkgyg/CFwarp/raw/main/CFwarp.sh && bash CFwarp.sh <<EOF
1
1
3
EOF
clear
